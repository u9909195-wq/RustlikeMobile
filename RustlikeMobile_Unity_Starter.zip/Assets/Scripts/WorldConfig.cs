using UnityEngine;

[CreateAssetMenu(menuName = "Rustlike/World Config", fileName = "WorldConfig")]
public class WorldConfig : ScriptableObject
{
    [Header("Medium world target")]
    public float worldSizeMeters = 1500f;
    public int terrainResolution = 513;
    public float terrainHeight = 180f;

    [Header("Mobile performance")]
    [Range(0.5f, 1f)] public float renderScale = 0.8f;
    public int targetFrameRate = 60;
    public bool useBakedLighting = true;
    public bool enableOcclusionCulling = true;
}
