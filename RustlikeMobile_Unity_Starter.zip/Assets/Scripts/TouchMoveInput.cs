using UnityEngine;

/// <summary>
/// Простейший ввод через UI-кнопки/джойстик. Передайте ссылку на NetworkPlayer.
/// Для полноценного джойстика замените SetDirection данными выбранного UI-компонента.
/// </summary>
public class TouchMoveInput : MonoBehaviour
{
    [SerializeField] private NetworkPlayer player;

    public void SetDirection(Vector2 direction)
    {
        if (player != null)
            player.SetMoveInput(direction);
    }

    public void MoveForward() => SetDirection(Vector2.up);
    public void MoveBackward() => SetDirection(Vector2.down);
    public void MoveLeft() => SetDirection(Vector2.left);
    public void MoveRight() => SetDirection(Vector2.right);
    public void Stop() => SetDirection(Vector2.zero);
}
