using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Сервер авторитетно изменяет показатели выживания; клиенты получают реплицируемые значения.
/// </summary>
public class SurvivalStats : NetworkBehaviour
{
    public NetworkVariable<float> Health = new(100f,
        NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);
    public NetworkVariable<float> Hunger = new(100f,
        NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);
    public NetworkVariable<float> Thirst = new(100f,
        NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

    [SerializeField] private float hungerLossPerSecond = 0.08f;
    [SerializeField] private float thirstLossPerSecond = 0.13f;
    [SerializeField] private float starvationDamagePerSecond = 1.5f;

    private void Update()
    {
        if (!IsServer || !IsSpawned) return;

        Hunger.Value = Mathf.Max(0f, Hunger.Value - hungerLossPerSecond * Time.deltaTime);
        Thirst.Value = Mathf.Max(0f, Thirst.Value - thirstLossPerSecond * Time.deltaTime);

        if (Hunger.Value <= 0f || Thirst.Value <= 0f)
            Health.Value = Mathf.Max(0f, Health.Value - starvationDamagePerSecond * Time.deltaTime);
    }

    public void ServerRestoreFood(float amount)
    {
        if (!IsServer) return;
        Hunger.Value = Mathf.Clamp(Hunger.Value + amount, 0f, 100f);
    }

    public void ServerRestoreWater(float amount)
    {
        if (!IsServer) return;
        Thirst.Value = Mathf.Clamp(Thirst.Value + amount, 0f, 100f);
    }
}
