using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Минимальный сетевой персонаж. WASD используется только для проверки в Unity Editor.
/// Для Android подключите экранный джойстик и передавайте в SetMoveInput нормализованный вектор.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class NetworkPlayer : NetworkBehaviour
{
    [SerializeField] private float moveSpeed = 4.5f;
    [SerializeField] private float gravity = -18f;
    [SerializeField] private Transform cameraTarget;

    private CharacterController controller;
    private Vector2 moveInput;
    private float verticalVelocity;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    public override void OnNetworkSpawn()
    {
        if (cameraTarget != null)
            cameraTarget.gameObject.SetActive(IsOwner);
    }

    public void SetMoveInput(Vector2 input)
    {
        if (IsOwner)
            moveInput = Vector2.ClampMagnitude(input, 1f);
    }

    private void Update()
    {
        if (!IsOwner)
            return;

#if UNITY_EDITOR || UNITY_STANDALONE
        if (moveInput == Vector2.zero)
            moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
#endif

        Vector3 direction = new Vector3(moveInput.x, 0f, moveInput.y);
        if (direction.sqrMagnitude > 1f) direction.Normalize();

        if (direction.sqrMagnitude > 0.001f)
            transform.forward = direction;

        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;

        verticalVelocity += gravity * Time.deltaTime;
        Vector3 velocity = direction * moveSpeed;
        velocity.y = verticalVelocity;
        controller.Move(velocity * Time.deltaTime);

#if UNITY_EDITOR || UNITY_STANDALONE
        moveInput = Vector2.zero;
#endif
    }
}
