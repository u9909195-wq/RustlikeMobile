using UnityEngine;
using Unity.Netcode;

/// <summary>Подключите методы к UI-кнопкам Host и Client.</summary>
public class MobileSessionUI : MonoBehaviour
{
    public void StartHost()
    {
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.StartHost();
        else
            Debug.LogError("NetworkManager не найден в сцене.");
    }

    public void StartClient()
    {
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.StartClient();
        else
            Debug.LogError("NetworkManager не найден в сцене.");
    }

    public void StartServer()
    {
        if (NetworkManager.Singleton != null)
            NetworkManager.Singleton.StartServer();
        else
            Debug.LogError("NetworkManager не найден в сцене.");
    }

    public void Shutdown()
    {
        if (NetworkManager.Singleton != null && NetworkManager.Singleton.IsListening)
            NetworkManager.Singleton.Shutdown();
    }
}
