# Rustlike Mobile — Unity starter

Стартовый каркас мобильной survival-игры с сетевой основой.

## Целевые параметры
- Android
- Сбалансированная мобильная графика
- Средняя карта (ориентир: 1.5 × 1.5 км; пока это дизайн-цель, а не готовый уровень)
- Онлайн-мультиплеер через Unity Netcode for GameObjects (NGO)

## Важно
Это **исходный стартовый проект**, а не готовая игра и не APK. Для APK нужны Unity Editor,
Android Build Support (SDK/NDK/OpenJDK) и сборка на компьютере. Этот архив не содержит
проприетарные материалы Rust и не является точной копией Rust.

## Версия и пакеты
Рекомендуется Unity 2022.3 LTS или Unity 6 LTS.
Через Window → Package Manager → + → Add package by name добавьте:
- `com.unity.netcode.gameobjects`
- `com.unity.transport`

В Project Settings → Player:
- Active Input Handling: Both (или Input Manager)
- Scripting Backend: IL2CPP для Android
- Target Architectures: ARM64

## Подключение сцены
1. Создайте сцену `Main`.
2. Создайте пустой объект `NetworkManager`.
3. Добавьте компоненты `NetworkManager` и `UnityTransport`.
4. В NetworkManager задайте UnityTransport как Network Transport.
5. Создайте Capsule `Player`, добавьте `NetworkObject` и `NetworkPlayer`.
6. Назначьте Player в Network Prefabs у NetworkManager.
7. Создайте объект `GameSystems`, добавьте `SurvivalStats`.
8. На Canvas добавьте кнопки Host и Client и привяжите методы `StartHost` и `StartClient`
   из `MobileSessionUI`.
9. Для тестирования запустите два клиента в Editor/на двух устройствах. Для игры через
   интернет потребуется отдельная настройка relay/dedicated server; прямое подключение
   по локальной сети само по себе не обеспечивает глобальный матчмейкинг.

## Что уже есть в коде
- Сетевой игрок с простым управлением клавиатурой для проверки в Editor.
- Серверная модель голода, жажды и здоровья.
- Минимальный UI-контроллер Host/Client.
- Точки расширения для мобильного ввода и инвентаря.

## Следующий этап
Добавить экранный джойстик и кнопки, сбор ресурсов, инвентарь/крафт, строительство,
сохранение мира и серверную инфраструктуру. Не включайте клиенту полномочия на изменение
здоровья/инвентаря: игровые изменения должны проверяться сервером.
